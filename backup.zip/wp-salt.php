<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         'Fg04PfDoaNV8LC9T91jxMw2s8tggUIPRINsHyYnArs5Rgjvgubu9hXH1dmXA4qDy');
define('SECURE_AUTH_KEY',  'PAm2o4Uf3T5H5XfrMiLmXQ5tmUyLI4dYtpC5tJeXVb3cxCrJV2RdQHzyPV9FF5CR');
define('LOGGED_IN_KEY',    'v6eoVYsnqj31wQ6P04zMDA6cqQg7NcxwaLVonsCR9a3IPr4w7Py4rQ933U43dXGW');
define('NONCE_KEY',        'fhrC1mLFgIXQuTvRxDnUunKurVpTAjeYhfU7tyyaNzucDs49aXLEyItIxTeFcazJ');
define('AUTH_SALT',        'x0BiNLhyUm3jiuFPGLE3jx5qfNfi7XdsJ9NAzC7RHnDhXHH2AoKS4G9gXbbIFRST');
define('SECURE_AUTH_SALT', 'eHgzWdnMUB985L1p7FmXnRVJHLB2KsAmyPWvFCgPKvRj0AQqgf1uK8MQx4pamsfr');
define('LOGGED_IN_SALT',   '8GecBUHSIfJaMhb1huJipyCJK7WW5fFvTXm9N7NLICrXQuNrjDcS3gfJtJ05Biq8');
define('NONCE_SALT',       'bjQeE9CX5M0h1D9rhz8UrurNQvEYfruasC3PXayRW9USajcMKfVb8GeB2I7o1aKw');
