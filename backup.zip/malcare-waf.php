<?php
// Please validate auto_prepend_file setting before removing this file

if (file_exists('/home/401163.cloudwaysapps.com/rwmsssgdth/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php')) {
	define("MCDATAPATH", '/home/401163.cloudwaysapps.com/rwmsssgdth/public_html/wp-content/mc_data/');
	define("MCCONFKEY", 'd734262e42245df2ac58e2a9fa672aa6');
	include_once('/home/401163.cloudwaysapps.com/rwmsssgdth/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php');
}
